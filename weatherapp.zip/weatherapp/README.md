# weatherapp
lookup weather information by searching on a location. Made this project to practice my Android development skills.

Uses JDK 8.
